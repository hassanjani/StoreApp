enum ProductType {
  LATEST_PRODUCT,
  SELLER_PRODUCT,
}